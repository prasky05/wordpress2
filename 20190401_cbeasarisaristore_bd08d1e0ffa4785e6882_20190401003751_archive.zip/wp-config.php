<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the
 * installation. You don't have to use the web site, you can
 * copy this file to "wp-config.php" and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * MySQL settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://codex.wordpress.org/Editing_wp-config.php
 *
 * @package WordPress
 */

// ** MySQL settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define('DB_NAME', 'wordpress2');

/** MySQL database username */
define('DB_USER', 'root');

/** MySQL database password */
define('DB_PASSWORD', '');

/** MySQL hostname */
define('DB_HOST', 'localhost');

/** Database Charset to use in creating database tables. */
define('DB_CHARSET', 'utf8mb4');

/** The Database Collate type. Don't change this if in doubt. */
define('DB_COLLATE', '');

/**#@+
 * Authentication Unique Keys and Salts.
 *
 * Change these to different unique phrases!
 * You can generate these using the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}
 * You can change these at any point in time to invalidate all existing cookies. This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         '>ISa!GVCC0{4ZJ<Twky<6o8k6 f :r%f8i_UH@Ea|<GtN=tYO>`M7.])L$|k|qU?');
define('SECURE_AUTH_KEY',  'Wv_Wt};63WP{9|hdY@y)SPe|{6f#~*L@R* e3tCHA59a sA_QRhqq{($2I8:-<R#');
define('LOGGED_IN_KEY',    ';fnJox?@oU[P*I2_u,9-bwrZH.C_^BI&Xtw$-9H+<LrCG(?@$[_FdP4,!q9raGdH');
define('NONCE_KEY',        '5a=k^GHTnNE+zRo$h/9i.4l]e^mFJ|]>*HP)k>0RTN~{5/HGL%qEPrdUo?Y`8cHE');
define('AUTH_SALT',        'm!x]M-]gh>:n)hvV^e!+_JNyltAG$6hYlqv/GQ=WSMfO$U#jvyDBk>#Sf1Qog:+,');
define('SECURE_AUTH_SALT', 'TUKgf]W%$^)L|i>xPd9pMv%#E$`V,ZIqP#U0wGqU-G}eQ!H8x?:AD@J1FM|t!?(Z');
define('LOGGED_IN_SALT',   '2,8eryTQGBOe/~<01AYZ_?Fk:NS/Z>v}Qd:3iEGBQbgA;+Al ;rSnGq!CMo;Cy3B');
define('NONCE_SALT',       'ez66=:/bz7Mf?Inqsw(-J_K-N?QmeW>M%n0N@EKHBX1<$/T%m!C68-kR6XX.G5ew');

/**#@-*/

/**
 * WordPress Database Table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix  = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the Codex.
 *
 * @link https://codex.wordpress.org/Debugging_in_WordPress
 */
define('WP_DEBUG', false);

/* That's all, stop editing! Happy blogging. */

/** Absolute path to the WordPress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');
