<?php
if (!class_exists('SnapLib_32BitSizeLimitException')):
class SnapLib_32BitSizeLimitException extends Exception {}
endif;